# ProtectedApkResignerForWalle
一步解决应用加固导致Walle渠道信息失效的自动化脚本，自动生成渠道包

----------
# 基础配置：
- 按照config.py文件中的注释改成自己项目配置
- 各种渠道的定义是在channel这个文件中，请根据项目情况修改

# 众合及竹马打包步骤
- 将360加固好的包放到脚本工具根目录下，竹马：app-release.apk，众合：zhonghe-release.apk
- 修改config.py中众合和竹马版本号
- 修改是否竹马包布尔值 isZhuMa，竹马传True,众合传False
- 运行命令 `python ApkResigner.py`,即可自动生成所有渠道包。
- 竹马渠道包在文件夹zhumachannels中查看，众合渠道包在文件夹zhonghechannels中查看

----------
# 支持平台：（需要python环境）
- Windows (Test)
- Mac OS (Test)
- Linux


