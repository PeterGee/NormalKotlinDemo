﻿#!/usr/bin/python3
# -*-coding:utf-8-*-


# keystore信息

# Windows 下路径分割线请注意使用\\转义
# 是否竹马
import sys

isZhuMa = True
# 竹马版本号
zhumaVersion = "v7.0.0"
# 众合版本号
zhongheVersion = "v3.9.0"


def getKeyStorePath():
    if isZhuMa:
        return sys.path[0] + "/zhumakey/zhumakey.jks"
    else:
        return sys.path[0] + "/zhonghekey/zhonghe.jks"


def getKeyAlias():
    if isZhuMa:
        return "zhuma"
    else:
        return "zhonghezaixian"


def getKeyStorePassword():
    if isZhuMa:
        return "zhonghe@2015"
    else:
        return "zhonghezaixian"


def getKeyPassword():
    if isZhuMa:
        return "zhonghe@2015"
    else:
        return "zhonghezaixian"


def getSourceApkName():
    if isZhuMa:
        return "app-release.apk"
    else:
        return "zhonghe-release.apk"


def getAPPName():
    if isZhuMa:
        return "app"
    else:
        return "zhonghe"


keystorePath = getKeyStorePath()
keyAlias = getKeyAlias()
keystorePassword = getKeyStorePassword()
keyPassword = getKeyPassword()
protectedSourceApkName = getSourceApkName()

sdkBuildToolPath = "/Users/peter/customSDK/build-tools/33.0.0"
